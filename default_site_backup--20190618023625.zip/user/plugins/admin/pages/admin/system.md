---
title: Configuration
template: config
access:
    admin.configuration: true
    admin.super: true
---
