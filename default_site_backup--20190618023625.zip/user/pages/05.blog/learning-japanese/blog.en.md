---
title: 'Learning Japanese'
taxonomy:
    tag:
        - japan
        - japanese
---

I am a daily user of Japanese, and it's the main language used in my home. I am fluent in Japanese but far from perfect. I watch Japanese movies as-is without subtitles and I can read in Japanese for information or pleasure. Some of my skills, such as handwriting, are not as good as they once were.

As somebody who has been teaching English as a foreign language for years now, I'm interested in topics of [second language acquisition](https://en.wikipedia.org/wiki/Second-language_acquisition). This of course includes my own studies in Japanese as a second language.

There is a glut of Japanese guides, apps and information about learning Japanese on the internet, but I dislike most of them, and I feel the majority focus too much on beginners, or otherwise are about hawking a specific product. Here are a few links to information and resources that I believe may be useful to **all** learners. I personally have found these useful either now or in the past. Please note that this list is not intended to be exhaustive, and intentionally omits any print resources that I have used at this point in time. I may add these later.

### Some useful links for learners of Japanese
#### Online dictionaries and references
* [jisho.org](https://www.jisho.org) - an easy-to-use frontend for a number of online resources. Primarily the WWWJDIC, which I have mixed feelings about as detailed below. It has an easy Kanji search and links to other online references.
* [Jim Breen's WWWJDIC](http://nihongo.monash.edu/cgi-bin/wwwjdic?1C) - This is a Japanese -> English dictionary based on Jim Breen's [EDICT](https://en.wikipedia.org/wiki/EDICT) project. It is a useful reference for some English translations of Japanese words but offers very little information on the usage of words. Example sentences come from the [Tanaka Corpus](https://www.edrdg.org/wiki/index.php/Tanaka_Corpus), now maintained as part of the Tatoeba.org project. The corpus was made by students, and often contains unnatural Japanese expression, for example, many sentences begin with pronouns. I would not recommend this resource for putting your English words into Japanese.
* [weblio](https://www.weblio.jp) - A Japanese-interface site that is very popular in Japan. It draws from a number of real dictionaries and corpora, and the standard is generally higher than most other online resources. I recommend the [Japanese<->English interface](https://ejje.weblio.jp/).

#### Grammar
* [Tae Kim's Grammar Guide](http://www.guidetojapanese.org/learn/grammar) - A plain-English guide to Japanese grammar. I haven't used this resource for years but a quick glance tells me that not a huge amount of the content on the pages have changed. I honestly have never used any other online resource for Japanese grammar, because this is good enough to get you to upper-intermediate knowledge. Check out the rest of his site. I broadly agree with most of what he has to say about learning Japanese.

#### Kanji
* [Reviewing the Kanji](https://kanji.koohii.com/) - [Remembering the Kanji](https://en.wikipedia.org/wiki/Remembering_the_Kanji_and_Remembering_the_Hanzi) is a series of three books by [James Heisig](https://nirc.nanzan-u.ac.jp/en/staff/jheisig/). I used this website to help me learn the contents of the first two books of this series. I consider Heisig's method far and away the best method for learning Kanji.]
* [Kanji Damage](http://www.kanjidamage.com/) - Funny, irreverent website about Kanji, with a method similar to Heisig's. Lots of good mnemonics. Steven Schultz, the author used to have fantastic website called *Tokyo Damage Report* about the Tokyo punk scene, his translations, and art works. Sadly, it is no longer online.

#### Learning Vocabulary
* [iknow.jp](https://www.iknow.jp) - This is a paid website that I used to use, but I have not used it for about five years, so I cannot vouch for the quality nowadays. I learned 6000 words using this site, and I considered it worth the money. It is now operated by DMM, a huge internet media and services company in Japan. I don't know if it has changed much since then, but ironically it was the lack of new content that caused me to give up on using this.
* [Anki](https://apps.ankiweb.net/) - The big boi of [spaced repetition](https://en.wikipedia.org/wiki/Spaced_repetition) software. I highly recommend this as it is not only effective for memorizing **any** kind of information, but it is [free software](https://www.fsf.org/about/what-is-free-software). My recommendation is to eschew shared decks and make all your own flashcards. Yes, it is time consuming but I find the process of making cards useful for internalizing the content that you want to learn, and customizing for your needs will make the cards stick better. Please do some reading on how to implement spaced repetition before you give it a go. There are web and mobile interfaces for most devices.
 * Depending on your browser, there are also add-ons that help with making new vocabulary flashcards. I personally have set up an add-on call '[Nazeka](https://addons.mozilla.org/en-US/firefox/addon/nazeka/)' to help me easily make new vocabulary flashcards at the click of a button. 

#### Other advice
* I would advise avoiding language exchange websites. They're largely an excuse for dating. Oftentimes it's two people with little teaching skill trying to play teacher. At worst, it ends in one person dominating in one language. Really, making a friend who speaks a foreign language and using their language is better for your language skills, or better still, pay a teacher.
 * Classes can be okay, but often the pacing is too slow for a motivated student. See what is available in your area and try them out.
* Don't pay a lot of money for an online course. The contents can be gleaned from free resources.
* JLPT N5 through to N3 are fun challenges for newer learners, but they are not really difficult enough to prove any level of professional skill. Skip them or do them as a test for yourself - they won't impress employers.
* Don't waste time in English-language Japanese learning communities. Talking about Japanese in English will not help you get better at Japanese.
* Learn kanji from day 1. You should try and make kanji your biggest focus until you have learned the [Jōyō kanji](https://en.wikipedia.org/wiki/J%C5%8Dy%C5%8D_kanji). This will help you not only read more, but to learn new word compounds from encountering them 'in the wild' and breaking them down into their constituent kanji. Learning over 2000 kanji is a grind, so be prepared to practice multiple times a day. Doing one big session a day is more unpleasant and may cause you to burn out.