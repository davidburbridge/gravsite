---
title: Blog
taxonomy:
    category:
        - blog
child_type: blog
content:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
---

