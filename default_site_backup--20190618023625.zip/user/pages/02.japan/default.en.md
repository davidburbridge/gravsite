---
title: 'Japan & Japanese'
content:
    items:
        '@taxonomy.tag': japanese
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true
content2:
    items:
        '@taxonomy.tag': japan
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true
---

###  [Learning Japanese](/japan/learning-japanese)