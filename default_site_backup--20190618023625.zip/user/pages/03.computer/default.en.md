---
title: Computer-related
content:
    items:
        '@taxonomy.tag': linux
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true
content2:
    items:
        '@taxonomy.tag': development
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true
---

# I like using and learning about computers
I am, among many other things, passionate about Linux, free/libre software and using the computers and the internet as a tool to better inform and enrich my life. I have a full-time teaching job and I'm a father, but I think if I had all the time in the world, I'd love to spend even more time learning technologies!

## What I use
I primarily use the latest version of Fedora, with the KDE desktop environment. Previously I used the i3 tiling window manager, which I enjoyed a lot, but I felt like returning to the more traditional desktop metaphor and have found myself enjoying it. I also use Ubuntu on other computers, with LXQT as the DE.

I use bash as my shell, but I am curious about other shells as well. I use vim as my main text editor, but I like to use the mouse when I'm doing editing for web, so I use VS Code for web projects.

I'm actually not at all picky about Linux distributions, desktop environments and software that acts as a graphical frontend. I see them as useful abstractions for performing the same core tasks that can be performed on the command line.

I use WordPress extensively at work, and I'm learning more so that I can be more of a developer than an implementer. I also join local Wordpress meetups and have provided a little help before.

I would love to spend more time studying computer programming languages. I have primarily been interested in C, PHP, (vanilla) Javascript and a few functional languages.

## This site
This site uses [Grav](https://getgrav.org) as its CMS. I chose this system as it is a lightweight and modern flat-file CMS, not requiring a database. The current theme is a simple, clean theme using Bootstrap 4 called [Tikva](https://www.kuerbis.org/tikva-theme-for-grav-cms/) created by Ralf Geschke. Grav is written in PHP but uses the [Twig](https://twig.symfony.com/) templating engine. I use Twig to modify the theme to create my own page and blog templates. 

## My (technical) to-do list for this site
### Within a few months
* Add multilingual-support, and create Japanese variants of some of these pages.
* Include more information about technologies that I am interested in.
* Customize the theme to better suit my preferences.

### Longer-term
* Learn how to create my first PHP web apps that can serve as useful tools as teachers.
* Create a new theme using CSS Grid.

## Links
* [My Github](https://github.com/davidburbridge)