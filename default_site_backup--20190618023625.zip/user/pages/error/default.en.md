---
title: Error
---

# Nothing to see here.
You're probably seeing this because you followed a broken link. [Let me know ](/about-me/contact) so that I can fix it.