---
title: Home
---

# Hi, I'm Dave

I am an EFL teacher based in Takamatsu, a city in Shikoku, western Japan. This is my personal website for my projects and writings.
