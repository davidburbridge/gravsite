---
title: 'About Me'
admin:
    children_display_order: collection
---

![Me and my Family](familysmall.jpg)
* Name: David John Burbridge
* Year of Birth: 1988
* Raised: Bishop's Stortford, Hertfordshire, England
* Residing: Takamatsu, Kagawa, Japan
* Interests: computers, saltwater fishing, reading about my latest interest(s)
* Favorite food: Kamatama udon
* Favorite singer: Devin Townsend
* Languages spoken: British English (Native), Japanese (probably [B2/C1 level](https://en.wikipedia.org/wiki/Common_European_Framework_of_Reference_for_Languages))

I use gmail as my main email provider for now. My address is my first name, my middle initial 'j', and then my last name.