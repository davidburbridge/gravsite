---
title: About
class: home
profile: true
---

This is a standard page. It could be an **about page** or a summary page that outlines your many gifts and talents that you intend to bring to the world of web development.

This page has the header attribute `profile: true` that causes the bio information to be displayed at the top of the page.
