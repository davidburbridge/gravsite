# v1.4.0
## 03/21/2019

1. [](#new)
    * Set Dependency of Grav 1.5.10+ which has support for new **Deferred Block** Twig extension
    * Implement assets rendering using **Deferred Block** Twig extension 

# v1.3.0
## 07/14/2016

1. [](#new)
    * Added support for Disqus comments
1. [](#bugfix)
    * Fixed the post published date format
    * Fix setting the page language in the html tag
    * Fix code highlighting support
    
# v1.2.1
## 01/06/2016

1. [](#bugfix)
    * Fixed Polish translation
    * Fixed incorrect section tag

# v1.2.0
## 08/25/2015

1. [](#new)
    * Added Polish translations
    * Added Norwegian translations
1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.1.1
## 07/21/2015

1. [](#bugfix)
    * Fixed issue with Retina profile image

# v1.1.0
## 07/19/2015

1. [](#new)
    * Added Greek translations
1. [](#improved)
    * Sets `<html lang="en">` dynamically based on language and/or default

# v1.0.1
## 07/14/2015

1. [](#improved)
    * Updated blueprints

# v1.0.0
## 07/13/2015

1. [](#new)
    * ChangeLog started...
