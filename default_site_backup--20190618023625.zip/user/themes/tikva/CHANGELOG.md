# v0.1.7
## 07-04-2017

1. [](#bugfix)
    * The previous release was too fast - fixed version number in blueprint.yaml file. 
    
# v0.1.6
## 07-04-2017

1. [](#bugfix)
    * Fix URL of background image 

# v0.1.5
## 06-04-2017

1. [](#new)
    * Add option to enable navigation bar dropdown by mouseover
    * Add background image upload feature and its repeat options
    

# v0.1.4
## 23-03-2017

1. [](#new)
    * Add Bootstrap's slider component to build an image slider
    

# v0.1.3
## 11-03-2017

1. [](#new)
    * Add switch to change the navigation bar style, i.e. to place it not fixed on top
    * New feature: Set navigation text alignment (left as default, centered and right)
2. [](#bugfix)
    * CHANGELOG file fix to version 0.1.1
    

# v0.1.2
## 10-03-2017
    
1. [](#bugfix)
    * Fix blockquote issue, so it's not necessary to set the CSS class explitly

# v0.1.1
## 06-03-2017

1. [](#new)
    * Social Media icon settings. You can add buttons to link Social Media sites.  
    * The theme options are now splited into tabs.
    * Add options to set subfooter colors
2. [](#bugfix)
    * Fix URL to README on Github
    
# v0.1.0
##  19-02-2017

1. [](#new)
    * First release
    * ChangeLog started...
